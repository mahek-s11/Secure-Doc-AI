from detect_forgery import detect_forgery

# Sample document
document = {
    "document_id": "salary_slip_tampered_001",
    "document_type": "salary_slip",
    "ocr_confidence": 0.95,
    "gross_salary": 72500,
    "net_salary": 96800,
    "opening_balance": 0,
    "closing_balance": 0,
    "market_value": 0
}

result = detect_forgery(document)

print(result)