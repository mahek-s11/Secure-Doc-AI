import json

with open("master_dataset.json", "r") as f:
    data = json.load(f)

for doc in data["documents"]:
    if doc["document_type"] == "bank_statement" and doc["label"] == "tampered":
        print(doc)
        break

print("\n" + "="*50 + "\n")

for doc in data["documents"]:
    if doc["document_type"] == "property_document" and doc["label"] == "tampered":
        print(doc)
        break