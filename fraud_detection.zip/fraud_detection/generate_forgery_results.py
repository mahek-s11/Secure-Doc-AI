import os
import json
import pandas as pd

from detect_forgery import detect_forgery

# Base directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Load dataset
dataset_path = os.path.join(BASE_DIR, "data", "master_dataset.json")

with open(dataset_path, "r") as f:
    data = json.load(f)

results = []

for document in data["documents"]:
    result = detect_forgery(document)
    results.append(result)

# Save results
output_path = os.path.join(BASE_DIR, "outputs", "forgery_results.json")

with open(output_path, "w") as f:
    json.dump(results, f, indent=4)

print(f"Generated {len(results)} predictions.")
print(f"Saved to: {output_path}")