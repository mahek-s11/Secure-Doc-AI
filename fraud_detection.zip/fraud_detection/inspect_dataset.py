import json

with open("master_dataset.json", "r") as f:
    data = json.load(f)

first_doc = data["documents"][0]

print("Features:")
for key in first_doc.keys():
    print(key)