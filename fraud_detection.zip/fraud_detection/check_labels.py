import json
import pandas as pd

with open("master_dataset.json", "r") as f:
    data = json.load(f)

df = pd.DataFrame(data["documents"])

print(df["label"].value_counts())