import joblib
import pandas as pd

# Load model
model = joblib.load("fraud_detection_model.pkl")

# Sample document
sample = pd.DataFrame([{
    "ocr_confidence": 0.95,
    "gross_salary": 72500,
    "net_salary": 66800,
    "opening_balance": 0,
    "closing_balance": 0,
    "market_value": 0
}])

# Probability
probability = model.predict_proba(sample)[0][1]

forgery_score = round(probability * 100, 2)

tampering_flag = forgery_score > 50

print("Forgery Score:", forgery_score)
print("Tampering Flag:", tampering_flag)