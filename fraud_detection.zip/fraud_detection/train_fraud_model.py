import json
import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score
import joblib

# Load JSON
with open("master_dataset.json", "r") as f:
    data = json.load(f)

df = pd.DataFrame(data["documents"])

# Convert label
df["label"] = df["label"].map({
    "genuine": 0,
    "tampered": 1
})

# Keep only useful numeric features
features = [
    "ocr_confidence",
    "gross_salary",
    "net_salary",
    "opening_balance",
    "closing_balance",
    "market_value"
]

# Missing values become 0
X = df[features].fillna(0)

y = df["label"]

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Train model
model = XGBClassifier(
    n_estimators=100,
    max_depth=4,
    learning_rate=0.1
)

model.fit(X_train, y_train)

# Test accuracy
predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)

print("Accuracy:", accuracy)

# Save model
joblib.dump(model, "fraud_detection_model.pkl")

print("Model Saved Successfully")