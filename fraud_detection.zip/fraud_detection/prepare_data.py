import json
import pandas as pd

with open("master_dataset.json", "r") as f:
    data = json.load(f)

df = pd.DataFrame(data["documents"])

print(df.head())
print("\nColumns:")
print(df.columns.tolist())
print("\nShape:")
print(df.shape)