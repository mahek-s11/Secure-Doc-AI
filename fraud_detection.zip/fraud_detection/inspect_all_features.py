import json

with open("master_dataset.json", "r") as f:
    data = json.load(f)

all_features = set()

for doc in data["documents"]:
    all_features.update(doc.keys())

print("All Features:")
for feature in sorted(all_features):
    print(feature)