import joblib
import pandas as pd

# Load the trained model only once
model = joblib.load("models/fraud_detection_model.pkl")


def detect_forgery(document_data):
    """
    Predicts forgery score and tampering flag for a document.

    Input:
        document_data (dict)

    Output:
        {
            "document_id": "...",
            "document_type": "...",
            "forgery_score": xx.xx,
            "tampering_flag": True/False
        }
    """

    # Features used during training
    features = {
        "ocr_confidence": document_data.get("ocr_confidence", 0),
        "gross_salary": document_data.get("gross_salary", 0),
        "net_salary": document_data.get("net_salary", 0),
        "opening_balance": document_data.get("opening_balance", 0),
        "closing_balance": document_data.get("closing_balance", 0),
        "market_value": document_data.get("market_value", 0)
    }

    df = pd.DataFrame([features])

    probability = model.predict_proba(df)[0][1]

    forgery_score = round(float(probability) * 100, 2)

    tampering_flag = forgery_score > 50

    if forgery_score >= 80:
        risk_level = "High"
    elif forgery_score >= 50:
        risk_level = "Medium"
    else:
        risk_level = "Low"

    return {
    "document_id": document_data.get("document_id"),
    "document_type": document_data.get("document_type"),
    "forgery_score": forgery_score,
    "tampering_flag": bool(tampering_flag),
    "risk_level": risk_level
}